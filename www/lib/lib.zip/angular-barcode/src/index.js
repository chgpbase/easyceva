import BarcodeDirective from './angular-barcode.directive.js';

export default angular.module('angular-barcode', []).directive('angularBarcode', BarcodeDirective);
