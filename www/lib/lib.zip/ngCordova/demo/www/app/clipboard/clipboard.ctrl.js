angular.module('demo.clipboard.ctrl', [])

  .controller('ClipboardCtrl', function ($scope, $log, $cordovaPreferences) {

  });
